package ru.urfu.cake.core.config;

import lombok.AllArgsConstructor;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.StreamsConfig;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import ru.urfu.cake.core.process.DeadLetterPublisher;

import java.util.HashMap;
import java.util.Map;
/**
 * Конфигурация Kafka Streams
 */
@AutoConfiguration
@EnableKafkaStreams
@EnableConfigurationProperties(KafkaProperties.class)
@AllArgsConstructor
public class KafkaConfiguration {
    private final KafkaProperties properties;
    /**
     * Свойства
     */
    @Bean(name = "defaultKafkaStreamsConfig")
    public KafkaStreamsConfiguration kafkaStreamsConfiguration() {
        Map<String, Object> props = new HashMap<>();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, properties.getApplicationId());
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, properties.getBootstrapServers());
        props.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, KafkaLoggingDeserializationExceptionHandler.class);
        return new KafkaStreamsConfiguration(props);
    }
    /**
     * Фабрика продюсеров
     */
    @Bean
    public ProducerFactory<String, String> producerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, properties.getBootstrapServers());
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        return new DefaultKafkaProducerFactory<>(config);
    }
    /**
     *
     */
    @Bean
    public KafkaTemplate<String, String> kafkaTemplate(ProducerFactory<String, String> producerFactory) {
        return new KafkaTemplate<>(producerFactory);
    }

    @Bean
    public DeadLetterPublisher deadLetterPublisher(KafkaTemplate<String, String> kafkaTemplate) {
        return new DeadLetterPublisher(kafkaTemplate);
    }

    @Bean
    public KafkaLogger topologyLogger() {
        return new KafkaLogger(new StreamsBuilderFactoryBean());
    }

    @Bean
    public NewTopic ordersTopic() {
        return TopicBuilder
                .name(properties.getTopics().getNotifications().name())
                .partitions(properties.getTopics().getNotifications().partitions())
                .replicas(properties.getTopics().getNotifications().replicationFactor())
                .config("retention.ms", String.valueOf(7 * 24 * 60 * 60 * 1000L))
                .build();
    }
}