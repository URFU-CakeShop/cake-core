package ru.urfu.cake.core.topology;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import ru.urfu.cake.core.process.DeadLetterPublisher;
import ru.urfu.cake.core.model.MessageHandler;

/**
 * Строит топологию Kafka Streams, делегирующую обработку сообщений
 * {@link MessageHandler}, фильтрующую null-записи и направляющую ошибки
 * в Dead Letter Queue (DLQ).
 * <p>
 * Микросервисы используют эту фабрику для подключения своих бизнес-обработчиков
 * без прямого взаимодействия с Kafka Streams.
 */
@Component
public class StreamTopologyFactory {
    private static final Logger log = LoggerFactory.getLogger(StreamTopologyFactory.class);

    private final DeadLetterPublisher deadLetterPublisher;
    private final ObjectMapper objectMapper;

    public StreamTopologyFactory(DeadLetterPublisher deadLetterPublisher, ObjectMapper objectMapper) {
        this.deadLetterPublisher = deadLetterPublisher;
        this.objectMapper = objectMapper;
    }

    /**
     * Строит поток на переданном {@code builder}, который:
     * <ul>
     *   <li>Читает из {@code topic} с ключами {@code String} и переданной {@code valueSerde}</li>
     *   <li>Фильтрует null-сообщения</li>
     *   <li>Передаёт каждую запись в {@code handler}</li>
     *   <li>При ошибке сериализует сообщение в JSON и публикует его в DLQ</li>
     * </ul>
     *
     * @param builder    {@link StreamsBuilder}, который нужно обогатить
     * @param topic      имя исходного топика
     * @param valueSerde сериализатор/десериализатор для значения сообщения
     * @param handler    бизнес-обработчик
     * @param <T>        тип сообщения
     */
    public <T> void buildStream(StreamsBuilder builder,
                                String topic,
                                Serde<T> valueSerde,
                                MessageHandler<T> handler) {
        builder
                .stream(topic, Consumed.with(Serdes.String(), valueSerde))
                .filter((key, value) -> {
                    if (value == null) {
                        log.warn("Received null message key={} topic={} — skipping", key, topic);
                        return false;
                    }
                    return true;
                })
                .foreach((key, value) -> {
                    try {
                        handler.handle(value);
                    } catch (Exception e) {
                        log.error("Error processing message key={} topic={}", key, topic, e);
                        publishToDlq(topic, key, value, e);
                    }
                });
    }

    private <T> void publishToDlq(String topic, String key, T value, Exception exception) {
        try {
            String json = objectMapper.writeValueAsString(value);
            deadLetterPublisher.publish(topic, key, json, null, exception);
        } catch (Exception serializationEx) {
            log.error("Failed to serialise message for DLQ topic={}", topic, serializationEx);
        }
    }
}
