package ru.urfu.cake.core.process;

import ru.urfu.cake.core.model.MessagePublisher;

public class MessagePublisherImpl<T> implements MessagePublisher<T> {
    /**
     * Опубликовать сообщение
     *
     * @param message Сообщение
     */
    @Override
    public void publish(T message) {

    }
}
