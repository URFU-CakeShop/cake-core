package ru.urfu.cake.core.process.notification;

import lombok.Data;
import lombok.Setter;

import java.util.Map;
import java.util.UUID;
/**
 * Уведомление
 */
@Data
@Setter
public class NotificationTask {
    private UUID userId;
    private String type;
    private String status;
    private Map<String, Object> payload;
    private String to;
    private String subject;
    private String htmlContent;
}