package ru.urfu.cake.core.process.notification;

import org.springframework.context.annotation.Scope;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import ru.urfu.cake.core.model.MessagePublisher;
/**
 * Планировщик задач на отправку уведомлений
 */
@Component
@Scope("singleton")
public class NotificationTaskMessageScheduler implements MessagePublisher<NotificationTask> {
    private final KafkaTemplate<String, NotificationTask> template;
    /**
     * Название TOPIC
     */
    public final static String TOPIC = "notifications";
    /**
     * Конструктор
     *
     * @param template
     */
    public NotificationTaskMessageScheduler(KafkaTemplate<String, NotificationTask> template) {
        this.template = template;
    }
    /**
     * Публикация сообщения
     *
     * @param message Сообщение
     */
    @Override
    public void publish(NotificationTask message) {
        template.send(TOPIC, message.getUserId().toString(), message);
    }
}
