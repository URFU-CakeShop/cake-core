package ru.urfu.cake.core.model;
/**
 * Обработчик сообщений
 *
 * @param <T> Тип сообщения
 */
public interface MessageHandler<T> {
    /**
     * Обработать сообщение
     *
     * @param message Сообщение
     */
    void handle(T message) throws Exception;
}
