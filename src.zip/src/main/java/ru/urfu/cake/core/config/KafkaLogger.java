package ru.urfu.cake.core.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;
/**
 * Логгер к Kafka Stream
 *
 * @param factoryBean
 */
public record KafkaLogger(
    StreamsBuilderFactoryBean factoryBean
) implements ApplicationListener<ApplicationReadyEvent>  {
    private static final Logger log = LoggerFactory.getLogger(KafkaLogger.class);
    /**
     * Событие готовности
     *
     * @param event Событие
     */
    @Override
    public void onApplicationEvent(ApplicationReadyEvent event) {
        if (factoryBean.getTopology() != null) {
            log.info(
                "Kafka Streams topology:\n{}",
                factoryBean.getTopology().describe()
            );
        }
    }
}