package ru.urfu.cake.core.model;
/**
 * Публикатор сообщений
 *
 * @param <T> Тип сообщения
 */
public interface MessagePublisher<T> {
    /**
     * Опубликовать сообщение
     *
     * @param message Сообщение
     */
    void publish(T message);
}
