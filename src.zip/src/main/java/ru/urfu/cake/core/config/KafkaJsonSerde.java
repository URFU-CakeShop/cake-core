package ru.urfu.cake.core.config;

import org.apache.kafka.common.serialization.Serdes;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
/**
 * Serde для JSON-сериализации и десериализации сообщений Kafka
 *
 * @param <T> тип сообщения
 */
public class KafkaJsonSerde<T> extends Serdes.WrapperSerde<T> {
    /**
     * Конструктор
     *
     * @param clazz Класс
     */
    public KafkaJsonSerde(Class<T> clazz) {
        super(new JsonSerializer<>(), new JsonDeserializer<>(clazz));
    }
}
