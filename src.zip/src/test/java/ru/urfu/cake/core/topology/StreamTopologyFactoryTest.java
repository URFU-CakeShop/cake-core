package ru.urfu.cake.core.topology;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.TestInputTopic;
import org.apache.kafka.streams.TopologyTestDriver;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ru.urfu.cake.core.process.DeadLetterPublisher;
import ru.urfu.cake.core.model.MessageHandler;
import ru.urfu.cake.core.config.KafkaJsonSerde;

import java.util.Properties;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

class StreamTopologyFactoryTest {

    private static final String TEST_TOPIC = "test-topic";

    private final DeadLetterPublisher deadLetterPublisher = mock();
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final StreamTopologyFactory factory = new StreamTopologyFactory(deadLetterPublisher, objectMapper);
    private final KafkaJsonSerde<TestMessage> serde = new KafkaJsonSerde<>(TestMessage.class);

    private TopologyTestDriver driver;

    @BeforeEach
    void setUp() {
        var builder = new StreamsBuilder();
        factory.buildStream(builder, TEST_TOPIC, serde, mock());
        var topology = builder.build();

        var props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "dummy:1234");
        driver = new TopologyTestDriver(topology, props);
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.close();
        }
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldProcessValidMessage() throws Exception {
        var handler = (MessageHandler<TestMessage>) mock(MessageHandler.class);
        var builder = new StreamsBuilder();
        factory.buildStream(builder, TEST_TOPIC, serde, handler);
        driver = new TopologyTestDriver(builder.build(), testProps());

        var input = inputTopic();
        var message = new TestMessage("hello");

        input.pipeInput("key1", message);

        verify(handler).handle(message);
        verify(deadLetterPublisher, never()).publish(anyString(), anyString(), anyString(), any(), any());
    }

    @Test
    @SuppressWarnings("unchecked")
    void shouldSendToDlqOnHandlerException() throws Exception {
        var handler = (MessageHandler<TestMessage>) mock(MessageHandler.class);
        doThrow(new RuntimeException("processing error")).when(handler).handle(any());

        var builder = new StreamsBuilder();
        factory.buildStream(builder, TEST_TOPIC, serde, handler);
        driver = new TopologyTestDriver(builder.build(), testProps());

        var input = inputTopic();
        var message = new TestMessage("fail");

        input.pipeInput("key1", message);

        verify(handler).handle(message);
        verify(deadLetterPublisher).publish(eq(TEST_TOPIC), eq("key1"), anyString(), eq(null), any());
    }

    @Test
    void shouldFilterNullValue() {
        var input = driver.createInputTopic(
                TEST_TOPIC,
                Serdes.String().serializer(),
                serde.serializer()
        );

        input.pipeInput("null-key", (TestMessage) null);

        verifyNoInteractions(deadLetterPublisher);
    }

    private TestInputTopic<String, TestMessage> inputTopic() {
        return driver.createInputTopic(
                TEST_TOPIC,
                Serdes.String().serializer(),
                serde.serializer()
        );
    }

    private static Properties testProps() {
        var props = new Properties();
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "test");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "dummy:1234");
        return props;
    }

    static class TestMessage {
        private String value;

        public TestMessage() {
        }

        public TestMessage(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            TestMessage that = (TestMessage) o;
            return java.util.Objects.equals(value, that.value);
        }

        @Override
        public int hashCode() {
            return java.util.Objects.hash(value);
        }
    }
}
