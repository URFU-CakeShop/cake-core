package ru.urfu.cake.core.integration;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import ru.urfu.cake.core.config.KafkaJsonSerde;
import ru.urfu.cake.core.process.DeadLetterPublisher;
import ru.urfu.cake.core.topology.StreamTopologyFactory;

import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;

class KafkaStreamsIntegrationTest {

    private static final String TEST_MESSAGE_VALUE = "{\"value\":\"test-message\"}";

    private AdminClient adminClient;
    private String bootstrapServers;

    @BeforeEach
    void setUp() {
        bootstrapServers = System.getProperty("kafka.bootstrap.servers", "localhost:9092");

        adminClient = AdminClient.create(Map.of(
                AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers
        ));
    }

    @AfterEach
    void tearDown() {
        if (adminClient != null) {
            adminClient.close();
        }
    }

    @Test
    @Timeout(60)
    void shouldPublishToDlqTopic() throws Exception {
        var sourceTopic = "dlq-test-source-" + UUID.randomUUID();
        var dlqTopic = sourceTopic + ".DLQ";
        createTopics(sourceTopic, dlqTopic);

        var deadLetterPublisher = new DeadLetterPublisher(createKafkaTemplate());

        deadLetterPublisher.publish(
                sourceTopic,
                "test-key",
                TEST_MESSAGE_VALUE,
                null,
                new RuntimeException("test error")
        );

        TimeUnit.SECONDS.sleep(2);

        var records = consumeFromTopic(dlqTopic, 1);
        assertThat(records.count()).isPositive();
        var record = records.iterator().next();
        assertThat(record.key()).isEqualTo("test-key");
        assertThat(record.value()).isEqualTo(TEST_MESSAGE_VALUE);
    }

    @Test
    @Timeout(60)
    void shouldProduceAndConsumeWithKafkaClients() throws Exception {
        var topic = "basic-test-topic-" + UUID.randomUUID();
        createTopics(topic);

        var producer = createProducer();
        var sent = producer.send(new ProducerRecord<>(topic, "my-key", "my-value")).get();
        producer.flush();
        producer.close();
        assertThat(sent).isNotNull();

        var records = consumeFromTopic(topic, 1);
        assertThat(records.count()).isPositive();
        var record = records.iterator().next();
        assertThat(record.key()).isEqualTo("my-key");
        assertThat(record.value()).isEqualTo("my-value");
    }

    @Test
    @Timeout(60)
    void shouldCreateAndDescribeTopics() throws Exception {
        var topic = "describe-test-topic-" + UUID.randomUUID();
        createTopics(topic);

        var description = adminClient.describeTopics(List.of(topic))
                .allTopicNames().get();
        assertThat(description).containsKey(topic);
        var topicDesc = description.get(topic);
        assertThat(topicDesc.partitions()).hasSize(1);
        assertThat(topicDesc.name()).isEqualTo(topic);
    }

    @Test
    @Timeout(60)
    void shouldHandleNullValue() throws Exception {
        var topic = "null-value-test-" + UUID.randomUUID();
        createTopics(topic);

        var producer = createProducer();
        producer.send(new ProducerRecord<>(topic, "key-null", (String) null)).get();
        producer.flush();
        producer.close();

        var records = consumeFromTopic(topic, 1);
        assertThat(records.count()).isPositive();
        var record = records.iterator().next();
        assertThat(record.key()).isEqualTo("key-null");
        assertThat(record.value()).isNull();
    }

    @Test
    @Timeout(60)
    void shouldBuildValidTopology() {
        var topologyFactory = new StreamTopologyFactory(
                new DeadLetterPublisher(createKafkaTemplate()),
                new ObjectMapper()
        );
        var builder = new org.apache.kafka.streams.StreamsBuilder();
        var serde = new KafkaJsonSerde<>(TestMessage.class);
        topologyFactory.buildStream(builder, "test-topic", serde,
                message -> { });

        var topology = builder.build();
        assertThat(topology.describe().toString())
                .contains("test-topic")
                .contains("KSTREAM-FILTER")
                .contains("KSTREAM-FOREACH");
    }

    private void createTopics(String... topics) throws Exception {
        var newTopics = List.of(topics).stream()
                .map(name -> new NewTopic(name, 1, (short) 1))
                .toList();
        adminClient.createTopics(newTopics).all().get();
    }

    private ConsumerRecords<String, String> consumeFromTopic(String topic, int expectedMin) {
        var consumer = createConsumer();
        var partitionInfo = consumer.partitionsFor(topic);
        if (partitionInfo == null || partitionInfo.isEmpty()) {
            consumer.close();
            throw new RuntimeException("No partitions found for topic: " + topic);
        }
        consumer.assign(partitionInfo.stream()
                .map(info -> new TopicPartition(info.topic(), info.partition()))
                .toList());
        consumer.seekToBeginning(Collections.emptyList());
        ConsumerRecords<String, String> records;
        long deadline = System.currentTimeMillis() + 30000;
        do {
            records = consumer.poll(Duration.ofSeconds(3));
            if (records.count() >= expectedMin) {
                break;
            }
        } while (System.currentTimeMillis() < deadline);
        consumer.close();
        return records;
    }

    private KafkaConsumer<String, String> createConsumer() {
        var props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "test-group-" + UUID.randomUUID());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        return new KafkaConsumer<>(props);
    }

    private KafkaProducer<String, String> createProducer() {
        var props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        props.put(ProducerConfig.ACKS_CONFIG, "all");
        return new KafkaProducer<>(props);
    }

    private org.springframework.kafka.core.KafkaTemplate<String, String> createKafkaTemplate() {
        var producerProps = new java.util.HashMap<String, Object>();
        producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        producerProps.put(ProducerConfig.ACKS_CONFIG, "all");
        var producerFactory = new org.springframework.kafka.core.DefaultKafkaProducerFactory<String, String>(producerProps);
        return new org.springframework.kafka.core.KafkaTemplate<>(producerFactory);
    }

    static class TestMessage {
        private String value;

        public TestMessage() {}

        public TestMessage(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
}
